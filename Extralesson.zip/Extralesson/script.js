document.body.innerHTML = `
    <h1 id="title">Hello from JavaScript</h1>
    <button id="btn">Click Me</button>
`;

// Add CSS using JavaScript
const style = document.createElement("style");
style.textContent = `
    #title {
        color: #003DA5;
        text-align: center;
        font-family: Arial;
    }

    #btn {
        background-color: #003DA5;
        color: white;
        padding: 12px 20px;
        border: none;
        cursor: pointer;
    }
`;
document.head.appendChild(style);

// JavaScript functionality
document.getElementById("btn").onclick = () => 
    document.getElementById("title").textContent = "Button Clicked!"